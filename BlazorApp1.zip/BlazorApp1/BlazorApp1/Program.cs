using BlazorApp1.Components;
using BlazorApp1.Helper.HttpClientHelper;
using Microsoft.Extensions.Hosting;
using Microsoft.JSInterop;
using Newtonsoft.Json.Linq;
using Syncfusion.Blazor.Grids;
using System.Net.Http.Headers;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddTransient<IHttpClientHelper, HttpClientHelper>();

//builder.Services.AddHttpClient();

builder.Services.AddHttpClient("WebAPI", c =>
    {
        c.BaseAddress = new Uri(builder.Configuration["AppSettings:ApiUrl"].ToString());
        c.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        // c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
        c.Timeout = TimeSpan.FromMinutes(30);
    });



var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
