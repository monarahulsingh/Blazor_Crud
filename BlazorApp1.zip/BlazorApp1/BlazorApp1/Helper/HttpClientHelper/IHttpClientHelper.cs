﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
namespace BlazorApp1.Helper.HttpClientHelper
{
    public interface IHttpClientHelper
    {
        Task<TOut> PostRequest<TIn, TOut>(TIn postData, string uri);
        Task<TOut> UpdateRequest<TIn, TOut>(TIn putData, string uri);
        Task<T> GetSingleItemRequest<T>(string uri);
        Task<List<T>> GetMultipleItemsRequest<T>(string uri);
    }
}
