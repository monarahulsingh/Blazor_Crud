﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace BlazorApp1.Helper.HttpClientHelper
{

    public class HttpClientHelper : IHttpClientHelper
    {

        private readonly ILogger<HttpClientHelper> _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;



        public HttpClientHelper(IHttpClientFactory httpClientFactory, ILogger<HttpClientHelper> logger, IConfiguration configuration)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            _configuration = configuration;
        }

        public async Task<List<T>> GetMultipleItemsRequest<T>(string uri)
        {
            string strResponse = string.Empty;
            using (HttpClient client = _httpClientFactory.CreateClient("WebAPI"))
            {

                try
                {
                    // Get the response



                    HttpResponseMessage response = await client.GetAsync(uri).ConfigureAwait(false);
                    if (response.IsSuccessStatusCode)
                    {
                        // Get string data
                        strResponse = await response.Content.ReadAsStringAsync();
                    }
                    // Deserialize the data
                    return JsonConvert.DeserializeObject<List<T>>(strResponse);
                    // Get string data
                    //var data = response.Content.ReadAsStringAsync().Result;

                    // Deserialize the data
                    //return JsonConvert.DeserializeObject<List<T>>(data);
                }
                catch (Exception ex)
                {
                    // Logg error
                    _logger.LogError($"GetMultipleItemsRequest: {uri}. {ex.Message}");
                    throw ex;
                }
            }
        }

        public Task<T> GetSingleItemRequest<T>(string uri)
        {
            throw new NotImplementedException();
        }

        public async Task<TOut> PostRequest<TIn, TOut>(TIn postData, string uri)
        {

            string strResponse = string.Empty;
            using (HttpClient client = _httpClientFactory.CreateClient("WebAPI"))
            {
                #region
                //client.DefaultRequestHeaders.Clear();
                //client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json");


                using (StringContent content = new StringContent(JsonConvert.SerializeObject(postData, new JsonSerializerSettings
                { NullValueHandling = NullValueHandling.Ignore }), Encoding.UTF8, "application/json"))
                {
                    #endregion
                    try
                    {
                        //string json = JsonConvert.SerializeObject(postData);
                        //var content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await client.PostAsync(uri, content).ConfigureAwait(false);
                        if (response.IsSuccessStatusCode)
                        {
                            string data = await response.Content.ReadAsStringAsync();
                            return JsonConvert.DeserializeObject<TOut>(data);
                        }
                        else if (response.StatusCode == System.Net.HttpStatusCode.Conflict)
                        {
                            return default(TOut);
                        }
                        else
                        {
                            return default(TOut);
                        }
                    }

                    catch (Exception ex)
                    {
                        _logger.LogError($"PostRequest: {uri}. {ex.Message}");
                        throw ex;
                    }
                }
            }
        }


        public Task<TOut> UpdateRequest<TIn, TOut>(TIn putData, string uri)
        {
            throw new NotImplementedException();
        }
    }
}
