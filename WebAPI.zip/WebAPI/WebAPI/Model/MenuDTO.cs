﻿namespace WebAPI.Model
{
    public class MenuDTO
    {
        public int MenuId { get; set; }
        public int ParentId { get; set; }
        public string MenuName { get; set; }
        public string MenuUrl { get; set; }
        public string AppNavUrl { get; set; }
        public string MenuIcons { get; set; }
        public Boolean IsChecked { get; set; }
    }
}
