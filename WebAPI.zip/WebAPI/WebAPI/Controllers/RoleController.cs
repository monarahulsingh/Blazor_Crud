﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPI.IService;
using WebAPI.Service;

namespace WebAPI.Controllers
{    
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class RoleController : ControllerBase
    {
        
        readonly IRoleService _service;
        private readonly ILogger<UserController> _logger;
        public RoleController(IRoleService service, ILogger<UserController> logger)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        public IActionResult GetMenus()
        {
            // UserService _service = new UserService();
            return Ok(_service.GetMenus());
        }
    }
}
