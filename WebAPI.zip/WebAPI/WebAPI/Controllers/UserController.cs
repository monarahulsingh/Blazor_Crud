﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPI.IService;
using WebAPI.Model;
using WebAPI.Service;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class UserController : ControllerBase
    {
        readonly IUserService _service;
        private readonly ILogger<UserController> _logger;
        public UserController(IUserService service, ILogger<UserController> logger)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAllUser()
        {
            // UserService _service = new UserService();
            return Ok(_service.GetAllUser());
        }

        [HttpPost]
        public IActionResult AddUser([FromBody] UserModel obj)
        {
            // UserService _service = new UserService();
            return Ok(_service.AddUser(obj));
        }
    }
}
