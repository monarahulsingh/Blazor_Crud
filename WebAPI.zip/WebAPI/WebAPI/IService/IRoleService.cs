﻿using WebAPI.Model;

namespace WebAPI.IService
{
    public interface IRoleService
    {
        IEnumerable<MenuDTO> GetMenus();
    }
}
