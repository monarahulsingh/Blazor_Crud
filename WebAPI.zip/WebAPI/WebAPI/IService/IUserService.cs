﻿using WebAPI.Model;

namespace WebAPI.IService
{
    public interface IUserService
    {
        List<UserModel> GetAllUser();
        int AddUser(UserModel obj);
    }
}
