﻿using System.Data;
using WebAPI.IService;
using WebAPI.Model;
using WebAPI.Utility;

namespace WebAPI.Service
{
    public class RoleService : IRoleService
    {

        private Repository.Repository _Rep;
        public RoleService(Repository.Repository Rep)
        {
            _Rep = Rep;
        }

        public IEnumerable<MenuDTO> GetMenus()
        {
            
            try
            {
                DataSet ds = _Rep.GetFromADO("GetMenu");
                //foreach (DataRow row in ds.Tables[0].Rows)
                //{
                //    MenuDTO menu = new MenuDTO();
                //    usrlist.Add(menu);
                //}

                List<MenuDTO> usrlist = new List<MenuDTO>();
                usrlist = DataTableToList.ConvertDataTableToList<MenuDTO>(ds.Tables[0]);

                List<DataRow> list = ds.Tables[0].AsEnumerable().ToList();

                return usrlist;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public List<MenuDTO> GetLayoutMenusByRoleID(int roleId, int ThemeId)
        //{
        //    return _unitOfWork.customroleRepository.MenusByRoleId(roleId, ThemeId);
        //}
        //public Role GetMenusByRoleId(int roleId)
        //{
        //    try
        //    {
        //        Role role = _unitOfWork.roleRepository.Get(x => x.RoleId == roleId, includes: (q => q.Include(x => x.RoleMenuMapping))).FirstOrDefault();
        //        if (role != null)
        //        {
        //            return role;
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    return null;
        //}
    }
}
