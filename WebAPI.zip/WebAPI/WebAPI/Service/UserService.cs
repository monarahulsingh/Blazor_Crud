﻿using WebAPI.Model;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Xml.Linq;
using WebAPI.Repository;
using WebAPI.IService;
namespace WebAPI.Service
{
    public class UserService : IUserService
    {
        private Repository.Repository _Rep;
        public UserService(Repository.Repository Rep)
        {
            _Rep = Rep;
        }



        public List<UserModel> GetAllUser()
        {
            List<UserModel> usrlist = new List<UserModel>();
            try
            {
                DataSet ds = _Rep.GetFromADO("GetAllUser");
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    UserModel usr = new UserModel();
                    usr.UserId = row.Field<int>("UserId");
                    usr.FirstName = row.Field<string>("FirstName");
                    usr.LastName = row.Field<string>("LastName");

                    usrlist.Add(usr);
                }

                return usrlist;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public int AddUser(UserModel obj)
        {
            int returnValue = 0;

            try
            {
                SqlParameter[] parameterValue = [
                new SqlParameter("@FirstName", obj.FirstName),
                    new SqlParameter("@LastName", obj.LastName),
                ];

                returnValue = _Rep.AddFromADOWithParams("AddUser", parameterValue);
            }
            catch (Exception ex)
            {
                throw ex;
            }


            return returnValue;
        }
    }
}
