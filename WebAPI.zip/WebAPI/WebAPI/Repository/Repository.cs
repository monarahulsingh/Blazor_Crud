﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace WebAPI.Repository
{
    public class Repository
    {
        private IConfiguration Configuration;

        public Repository(IConfiguration _configuration)
        {
            Configuration = _configuration;
        }

        public DataSet GetFromADO(string SPName)
        {
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand();
            try
            {
                SqlConnection con = new SqlConnection(Configuration.GetConnectionString("DefaultConnection"));

                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = SPName;

                con.Open();
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    adapter.Fill(ds);
                }
                con.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            return ds;
        }
        public int AddFromADOWithParams(string SPName, params object[] parameters)
        {
            DataSet ds = new DataSet();
            SqlParameter param;
            SqlCommand cmd = new SqlCommand();
            int affectedRows = 0;
            try
            {
                SqlConnection con = new SqlConnection(Configuration.GetConnectionString("DefaultConnection"));
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = SPName;
                if (parameters != null)
                {
                    foreach (var item in parameters)
                    {
                        cmd.Parameters.Add(item);
                    }
                }
                if (con.State != ConnectionState.Open)
                    con.Open();
                affectedRows = cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            return affectedRows;
        }
    }
}
